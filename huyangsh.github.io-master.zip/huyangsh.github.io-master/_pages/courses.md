---
layout: archive
title: "Courses"
permalink: /courses/
author_profile: true
---

This is a selected list of courses that I have taken.

**Mathematics**
+ *Calculus A(1)*, Fall 2018, A+
+ *Linear Algebra*, Fall 2018, A
+ *Calculus A(2)*, Spring 2019, A
+ *Abstract Algebra*, Spring 2019, A+
+ *Mathematics for Computer Science*, Spring 2019, A

**Theory**
+ *Algebra and Computation*, Summer 2019, A
+ *Algorithm Design*, Fall 2019, A
+ *Network Science*, Fall 2019, A+
+ *Quantum Computer Science*, Spring 2020, A+
+ *Theory of Computation*, Spring 2021, A

**AI and Control**
+ *Artificial Intelligence*, Fall 2019, A
+ *Machine Learning*, Fall 2020, A
+ *Intelligent Systems and Robotics*, Fall 2021, *on-going*

**Systems**
+ *Fundamentals of Digital Electronics*, Fall 2019, A
+ *Distributed Computing*, Spring 2020, A
+ *Operating Systems*, Fall 2020, A+
+ *Advanced Computer Graphics*, Fall 2020, A